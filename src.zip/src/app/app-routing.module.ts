import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// Import components
import { HomePageComponent } from './home-page/home-page.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth.guard';

import { EmployeeListComponent } from './employee-list/employee-list.component';
import { AssignNumberComponent } from './assign-number/assign-number.component';
import { AddSimComponent } from './add-sim/add-sim.component';
import { AssignSimComponent } from './assign-sim/assign-sim.component';
import { SimListComponent } from './sim-list/sim-list.component';
import { SignupComponent } from './signup/signup.component';

const routes: Routes = [
  // Page d'accueil
  { path: 'home-page', component: HomePageComponent },

  // Pages d'authentification
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },

  // Routes protégées
  { path: 'employee-list', component: EmployeeListComponent, canActivate: [AuthGuard]  },
  { path: 'assign-number', component: AssignNumberComponent, canActivate: [AuthGuard]   },
  { path: 'add-sim', component: AddSimComponent, canActivate: [AuthGuard]  },
  { path: 'assign-sim', component: AssignSimComponent , canActivate: [AuthGuard] },
  { path: 'sim-list', component: SimListComponent, canActivate: [AuthGuard]  },

  // Wildcard route for undefined paths
  { path: '', redirectTo: '/home-page', pathMatch: 'full' },
  { path: '**', redirectTo: '/home-page' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
