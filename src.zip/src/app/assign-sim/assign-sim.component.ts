import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SimService } from '../sim.service';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-assign-sim',
  templateUrl: './assign-sim.component.html',
  styleUrls: ['./assign-sim.component.css']
})
export class AssignSimComponent implements OnInit {
  private apiUrl = 'http://localhost:5000/api'; 
  assignForm: FormGroup;  // Déclaration sans initialisation ici.
  forfait: string = '30 DT';  // Valeur par défaut
  forfaitInternet: string = '15 Go';  // Valeur par défaut
  detailsVisible: boolean = false; // Contrôle l'affichage du modal

  // Injection du FormBuilder pour créer un formulaire réactif
  constructor(private fb: FormBuilder) {
    // Initialisation de assignForm dans le constructeur
    this.assignForm = this.fb.group({
      nom: ['', Validators.required],
      cin: ['', Validators.required],
      poste: ['', Validators.required],
      service: ['', Validators.required],
      serialNumber: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    // Vous pouvez également ajouter des logiques supplémentaires dans ngOnInit
  }

  // Méthode pour gérer la soumission du formulaire
  onSubmit(): void {
    if (this.assignForm.valid) {
      // Affiche le modal avec les données saisies
      this.detailsVisible = true;
    }
  }

  // Méthode pour copier les données dans le presse-papiers
  copyToClipboard(): void {
    const dataToCopy = `
      Nom: ${this.assignForm.value.nom}
      CIN: ${this.assignForm.value.cin}
      Poste: ${this.assignForm.value.poste}
      Service: ${this.assignForm.value.service}
      Forfait: ${this.forfait}
      Forfait Internet: ${this.forfaitInternet}
      Serial Number: ${this.assignForm.value.serialNumber}
    `;
    navigator.clipboard.writeText(dataToCopy).then(() => {
      alert('Les données ont été copiées dans le presse-papiers');
    }).catch((error) => {
      console.error('Erreur lors de la copie dans le presse-papiers', error);
    });
  }

  // Méthode pour fermer le modal
  closeModal(): void {
    this.detailsVisible = false;
  }

  // Méthode pour gérer le changement de poste et mettre à jour les forfaits
  onPosteChange(): void {
    const poste = this.assignForm.get('poste')?.value;
    if (poste === 'technicien') {
      this.forfait = '30 DT';
      this.forfaitInternet = '15 Go';
    } else if (poste === 'specialiste') {
      this.forfait = '50 DT';
      this.forfaitInternet = '30 Go';
    } else if (poste === 'manager') {
      this.forfait = '70 DT';
      this.forfaitInternet = '30 Go';
    } else if (poste === 'directeur') {
      this.forfait = '100 DT';
      this.forfaitInternet = '30 Go';
    }
  }

  // Méthode pour gérer l'entrée du numéro de série
  onSerialNumberInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    console.log(input.value); // Vous pouvez ajuster cette logique selon vos besoins
  }
}