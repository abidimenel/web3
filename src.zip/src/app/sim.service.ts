import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SimService {
  private apiUrl = 'http://localhost:5000/api';  // URL de votre backend local

  constructor(private http: HttpClient) { }

  // Récupérer toutes les SIMs
  getAllSims(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/sim`);
  }

  // Ajouter une nouvelle SIM
  createSim(simData: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/sim`, simData);
  }

  // Attribuer une SIM à un employé
  assignSim(simData: any): Observable<any> {
    const httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
        }),
    };
return this.http.post<any>(`${this.apiUrl}/sim/assign`, simData, httpOptions);
}
}
