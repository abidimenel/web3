import { Component } from '@angular/core';
import { AuthService } from '..//auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
})
export class SignupComponent {
  email: string = '';
  password: string = '';
  confirmPassword: string = '';
  errorMessage: string = '';
  isSubmitting: boolean = false;

  constructor(private authService: AuthService) {}

  onSignUp() {
    if (this.password !== this.confirmPassword) {
      this.errorMessage = "Passwords don't match.";
      return;
    }

    this.isSubmitting = true;
    this.errorMessage = '';

    this.authService.signUp(this.email, this.password).subscribe(
      (response: { message: any; }) => {
        console.log('Sign-up successful:', response.message);
        alert('Account created successfully!');
        this.isSubmitting = false;
      },
      (error: { error: { message: string; }; }) => {
        console.error('Sign-up failed:', error.error);
        this.errorMessage = error.error.message || 'Error creating account.';
        this.isSubmitting = false;
      }
    );
  }
}
