import { Component } from '@angular/core';
import { SimService } from '../sim.service';  // Importation correcte si le service est dans le même répertoire que le composant


@Component({
  selector: 'app-add-sim',
  templateUrl: './add-sim.component.html',
  styleUrls: ['./add-sim.component.css'],
})
export class AddSimComponent {
  barcodeValue: string | null = ''; // Valeur du code barre actuellement scanné
  scannedChips: any[] = []; // Liste des puces scannées
  editingChip: any = null; // Chip en cours d'édition (si applicable)

  constructor(private simService: SimService) {}

  // Méthode appelée lorsque le code barre est scanné ou saisi manuellement
  onBarcodeScanned(): void {
    if (this.barcodeValue && this.barcodeValue.trim()) {
      if (this.editingChip) {
        // Si on est en mode édition, on met à jour la puce existante
        this.updateChip(this.barcodeValue.trim());
      } else {
        // Sinon, on ajoute une nouvelle puce
        this.addChipToBackend(this.barcodeValue.trim());
      }
    }
  }

  // Ajouter une puce au backend (et à la liste locale)
  addChipToBackend(barcode: string): void {
    // Créez un objet de données à envoyer au backend
    const newSim = {
      serialNumber: barcode,
      forfait: 'Standard', // Exemple de forfait (vous pouvez l'ajuster)
      forfaitInternet: '10GB', // Exemple de forfait Internet
    };

    // Appeler le service pour créer la SIM dans la base de données
    this.simService.createSim(newSim).subscribe(
      (data) => {
        // Si l'ajout est réussi, ajouter la SIM à la liste locale
        this.scannedChips.push({
          barcode,
          status: 'non validé', // Statut initial de la puce
        });
        this.barcodeValue = ''; // Réinitialiser la valeur du champ
      },
      (error) => {
        console.error('Erreur lors de l\'ajout de la SIM:', error);
        alert('Erreur lors de l\'ajout de la SIM.');
      }
    );
  }

  // Mettre à jour une puce dans la liste
  updateChip(barcode: string): void {
    if (this.editingChip) {
      this.editingChip.barcode = barcode; // Modifier le code barre de la puce
      this.editingChip = null; // Réinitialiser l'édition
    }
    this.barcodeValue = ''; // Réinitialiser la valeur du champ
  }

  // Méthode pour éditer un code barre
  editBarcode(chip: any): void {
    this.barcodeValue = chip.barcode; // Remplir la zone de saisie avec le code sélectionné
    this.editingChip = chip; // Marquer la puce comme étant en édition
  }

  // Méthode pour supprimer une puce de la liste
  deleteChip(chip: any): void {
    this.scannedChips = this.scannedChips.filter(c => c !== chip); // Supprimer la puce sélectionnée
  }
}
