import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-assign-number',
  templateUrl: './assign-number.component.html',
  styleUrls: ['./assign-number.component.css'],
})
export class AssignNumberComponent implements OnInit {
  assignForm: FormGroup; // Formulaire pour assigner le numéro
  isLoading: boolean = false; // Indicateur de chargement
  errorMessage: string = ''; // Message d'erreur

  constructor(private fb: FormBuilder, private employeeService: EmployeeService) {
    // Initialisation du formulaire avec des validations
    this.assignForm = this.fb.group({
      serialNumber: ['', [Validators.required, Validators.pattern('^[A-Za-z0-9]+$')]], // Validation pour les caractères alphanumériques
      numTelephone: [
        '',
        [Validators.required, Validators.pattern('^[0-9]{8}$')], // Numéro tunisien à 8 chiffres
      ],
    });
  }

  ngOnInit(): void {}

  /**
   * Gérer l'entrée dans le champ Serial Number
   */
  onSerialNumberInput(event: any): void {
    const serialNumber = event.target.value.trim();
    console.log('Serial Number scanné:', serialNumber);
    // Ajoutez ici une logique de validation supplémentaire si nécessaire
  }

  /**
   * Gérer la soumission du formulaire
   */
  onSubmit(): void {
    // Réinitialiser les messages d'erreur
    this.errorMessage = '';

    if (this.assignForm.valid) {
      this.isLoading = true; // Démarrer le chargement
      const formData = this.assignForm.value;

      this.employeeService.assignNumber(formData).subscribe(
        (response: any) => {
          this.isLoading = false; // Arrêter le chargement
          alert('Numéro de téléphone attribué avec succès!');
          this.assignForm.reset(); // Réinitialiser le formulaire après le succès
        },
        (error: any) => {
          this.isLoading = false; // Arrêter le chargement
          console.error('Erreur lors de l\'attribution du numéro de téléphone:', error);
          this.errorMessage =
            error.error?.message || 'Une erreur s\'est produite. Veuillez réessayer.';
        }
      );
    } else {
      this.errorMessage = 'Veuillez vérifier les champs du formulaire.';
    }
  }

  /**
   * Accès rapide aux champs du formulaire pour simplifier le code
   */
  get serialNumber() {
    return this.assignForm.get('serialNumber');
  }

  get numTelephone() {
    return this.assignForm.get('numTelephone');
  }
}
