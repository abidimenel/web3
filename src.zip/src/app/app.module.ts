import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { ZXingScannerModule } from '@zxing/ngx-scanner';  // Import ZXingScannerModule


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { PositionComponent } from './position/position.component';
import { AvailableNumberComponent } from './available-number/available-number.component';
import { HomePageComponent } from './home-page/home-page.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { AddNumberComponent } from './add-number/add-number.component';
import { NumbersListComponent } from './numbers-list/numbers-list.component';
import { AssignNumberComponent } from './assign-number/assign-number.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { ServiceListComponent } from './service-list/service-list.component';
import { AddServiceComponent } from './add-service/add-service.component';
import { SimListComponent } from './sim-list/sim-list.component';
import { AddSimComponent } from './add-sim/add-sim.component';
import { AssignSimComponent } from './assign-sim/assign-sim.component';
import { LoginComponent } from './login/login.component';
import { BarcodeTestComponent } from './barcode-test/barcode-test.component';
import { SignupComponent } from './signup/signup.component';
import { AuthService } from './auth.service';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    PositionComponent,
    AvailableNumberComponent,
    HomePageComponent,
    NavbarComponent,
    FooterComponent,
    AddNumberComponent,
    NumbersListComponent,
    AssignNumberComponent,
    EmployeeListComponent,
    AddEmployeeComponent,
    ServiceListComponent,
    AddServiceComponent,
    SimListComponent,
    AddSimComponent,
    AssignSimComponent,
    LoginComponent,
    BarcodeTestComponent,
    SignupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    ZXingScannerModule,  // Add ZXingScannerModule
  ],
  providers: [AuthService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA] // Add CUSTOM_ELEMENTS_SCHEMA if needed
})
export class AppModule { }
