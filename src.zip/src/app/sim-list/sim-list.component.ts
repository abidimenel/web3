import { Component, OnInit } from '@angular/core';
import { SimService } from '../sim.service';  // Assurez-vous que le service est importé

@Component({
  selector: 'app-sim-list',
  templateUrl: './sim-list.component.html',
  styleUrls: ['./sim-list.component.css'],
})
export class SimListComponent implements OnInit {
  sims: any[] = []; // Liste des puces
  searchQuery: string = ''; // Recherche

  constructor(private simService: SimService) {}  // Injection de SimService

  ngOnInit(): void {
    // Appel à l'API via le SimService pour récupérer les puces
    this.simService.getAllSims().subscribe(
      (data: any[]) => {
        this.sims = data;  // Stocker les données récupérées depuis le backend
      },
      (error: any) => {
        console.error('Erreur lors de la récupération des puces', error);
      }
    );
  }

  /**
   * Filtrer les puces selon la recherche.
   */
  filterSims(): any[] {
    const query = this.searchQuery.toLowerCase();
    return this.sims.filter((sim) =>
      sim.serialNumber.toLowerCase().includes(query) ||
      sim.dateDajout.toLowerCase().includes(query) ||
      sim.dateAttribution.toLowerCase().includes(query)
    );
  }
}
